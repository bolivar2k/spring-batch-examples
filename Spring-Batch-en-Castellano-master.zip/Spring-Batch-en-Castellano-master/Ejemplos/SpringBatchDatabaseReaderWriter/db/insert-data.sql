INSERT INTO Users VALUES (1, 'empleado1', 'empleado1@maldiny.com');
INSERT INTO Users VALUES (2, 'empleado2', 'empleado2@maldiny.com');
INSERT INTO Users VALUES (3, 'empleado3', 'empleado3@maldiny.com');