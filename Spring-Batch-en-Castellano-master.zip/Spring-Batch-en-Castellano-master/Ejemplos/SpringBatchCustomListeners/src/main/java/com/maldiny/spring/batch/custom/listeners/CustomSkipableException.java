package com.maldiny.spring.batch.custom.listeners;

public class CustomSkipableException extends Exception {

	
}
